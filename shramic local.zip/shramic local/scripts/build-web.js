const fs = require('fs');
const path = require('path');

const projectRoot = path.join(__dirname, '..');
const outputDirectory = path.join(projectRoot, 'www');
const files = [
  ['frontend', 'login.html'],
  ['frontend', 'shramic.html'],
  ['', 'shramic.css'],
  ['', 'shramic.js'],
  ['', 'i18n.js'],
  ['', 'manifest.webmanifest'],
  ['', 'service-worker.js']
];

fs.mkdirSync(outputDirectory, { recursive: true });

for (const [directory, file] of files) {
  fs.copyFileSync(
    path.join(projectRoot, directory, file),
    path.join(outputDirectory, file)
  );
}

fs.copyFileSync(
  path.join(projectRoot, 'frontend', 'login.html'),
  path.join(outputDirectory, 'index.html')
);

const iconDirectory = path.join(outputDirectory, 'icons');
fs.mkdirSync(iconDirectory, { recursive: true });
for (const icon of ['icon-192.png', 'icon-512.png']) {
  fs.copyFileSync(
    path.join(projectRoot, 'icons', icon),
    path.join(iconDirectory, icon)
  );
}

console.log(`Copied app web assets to ${path.relative(projectRoot, outputDirectory)}.`);
