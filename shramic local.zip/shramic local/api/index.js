const app = require('../backend/server');

module.exports = (req, res) => {
  const route = req.query.route;
  if (typeof route === 'string') {
    const queryString = req.url.includes('?')
      ? req.url.slice(req.url.indexOf('?') + 1)
      : '';
    const query = new URLSearchParams(queryString);
    query.delete('route');
    const remainingQuery = query.toString();
    req.url = `/api/${route.replace(/^\/+/, '')}` +
      (remainingQuery ? `?${remainingQuery}` : '');
  }

  return app(req, res);
};
